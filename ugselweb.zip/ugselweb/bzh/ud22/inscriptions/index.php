<?php
$HOSTNAME        = "localhost";
$UTILISATEUR     = "ugsel22";
$MDP             = "ud22*brt!";
$BDD             = "ugsel22";
$UGSELNOM        = "Ugsel 22";
$UGSELNOMDEP     = "C�tes d'Armor";
$ADMINLOGIN      = "bzh22";
$ADMINMDP        = "secug22";
$ADMINREGLOGIN   = "bzh";
$ADMINREGMDP     = "2229bzh3556!";
$LIGNES_PAR_PAGE = 500;
$TAILLE          = 4;
$LISTEBDD        = array();
$CONSULTATION    = "Non";
$LICENCES        = "Non";
include("../../../ugselweb.php");
?>
