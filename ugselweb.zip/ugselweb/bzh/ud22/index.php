<?php
$HOSTNAME        = "localhost";
$UTILISATEUR     = "ugsel22";
$MDP             = "ud22*brt!";
$BDD             = "ugsel22";
$UGSELNOM        = "Ugsel 22";
$UGSELNOMDEP     = "C�tes d'Armor";
$LIGNES_PAR_PAGE = 500;
$TAILLE          = 4;
$CONSULTATION    = "Oui";
include("../../ugselweb.php");
?>
