<?php
$HOSTNAME        = "localhost";
$UTILISATEUR     = "ugsel56";
$MDP             = "ug56*ijnx";
$BDD             = "ugsel56";
$UGSELNOM        = "Ugsel 56";
$UGSELNOMDEP     = "Morbihan";
$LIGNES_PAR_PAGE = 500;
$TAILLE          = 4;
$CONSULTATION    = "Oui";
include("../../ugselweb.php");
?>
