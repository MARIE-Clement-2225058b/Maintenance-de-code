<?php
$HOSTNAME        = "localhost";
$UTILISATEUR     = "ugsel56";
$MDP             = "ug56*ijnx";
$BDD             = "ugsel56";
$UGSELNOM        = "Ugsel 56";
$UGSELNOMDEP     = "Morbihan";
$ADMINLOGIN      = "bzh56";
$ADMINMDP        = "77bzh56";
$ADMINREGLOGIN   = "bzh";
$ADMINREGMDP     = "2229bzh3556!";
$LIGNES_PAR_PAGE = 500;
$TAILLE          = 4;
$LISTEBDD        = array();
$CONSULTATION    = "Non";
$LICENCES        = "Non";
include("../../../ugselweb.php");
?>
