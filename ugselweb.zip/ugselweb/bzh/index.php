<?php
$UGSELREG = array("bzh","Bretagne",130,175,"www.ugsel-bretagne.org");
$UGSELDEP = array(
array("22","C�tes d'Armor", 0,70),
array("29","Finist�re", 0,0),
array("35","Ille et Vilaine", 0,80),
array("56","Morbihan", 0,62)
);
include("../ugselwebaccueilregion.php");
?>
