<?php
$HOSTNAME        = "localhost";
$UTILISATEUR     = "ugsel35";
$MDP             = "ug35!xesw";
$BDD             = "ugsel35";
$UGSELNOM        = "Ugsel 35";
$UGSELNOMDEP     = "Ille et Vilaine";
$LIGNES_PAR_PAGE = 500;
$TAILLE          = 4;
$CONSULTATION    = "Oui";
include("../../ugselweb.php");
?>
