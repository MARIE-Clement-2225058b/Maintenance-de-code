<?php
$HOSTNAME        = "localhost";
$UTILISATEUR     = "ugsel35";
$MDP             = "ug35!xesw";
$BDD             = "ugsel35";
$UGSELNOM        = "Ugsel 35";
$UGSELNOMDEP     = "Ille et Vilaine";
$ADMINLOGIN      = "bzh35";
$ADMINMDP        = "35bzh28";
$ADMINREGLOGIN   = "bzh";
$ADMINREGMDP     = "2229bzh3556!";
$LIGNES_PAR_PAGE = 500;
$TAILLE          = 4;
$LISTEBDD        = array();
$CONSULTATION    = "Non";
$LICENCES        = "Non";
include("../../../ugselweb.php");
?>
