<?php
$HOSTNAME        = "localhost";
$UTILISATEUR     = "ugsel29";
$MDP             = "ud29!zsx5";
$BDD             = "ugsel29";
$UGSELNOM        = "Ugsel 29";
$UGSELNOMDEP     = "Finist�re";
$LIGNES_PAR_PAGE = 500;
$TAILLE          = 4;
$CONSULTATION    = "Oui";
include("../../ugselweb.php");
?>
