<?php
$HOSTNAME        = "localhost";
$UTILISATEUR     = "ugsel29";
$MDP             = "ud29!zsx5";
$BDD             = "ugsel29";
$UGSELNOM        = "Ugsel 29";
$UGSELNOMDEP     = "Finist�re";
$ADMINLOGIN      = "bzh29";
$ADMINMDP        = "46bzh29";
$ADMINREGLOGIN   = "bzh";
$ADMINREGMDP     = "2229bzh3556!";
$LIGNES_PAR_PAGE = 500;
$TAILLE          = 4;
$LISTEBDD        = array();
$CONSULTATION    = "Non";
$LICENCES        = "Non";
include("../../../ugselweb.php");
?>
